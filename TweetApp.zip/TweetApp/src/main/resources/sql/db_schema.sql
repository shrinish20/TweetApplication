create database if not exists tweetapplication;

create table if not exists tweetapplication.userData (
userId int auto_increment,
firstName varchar(100) not null,
lastName varchar(100),
gender varchar(10) not null,
dateOfBirth date not null,
emailAddress varchar(100) not null,
userPassword varchar(100) not null,
primary key (userId),
unique (emailAddress)
);

create table if not exists tweetapplication.tweetData (
userId int,
emailAddress varchar(100) not null,
tweet text,
foreign key (userId) references userData(userId)
);
