package com.tweetapp.model;

public class TweetPOJO {

	private String emailId;
	private String tweetMsg;

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the tweetMessage
	 */
	public String getTweetMsg() {
		return tweetMsg;
	}

	/**
	 * @param tweetMessage the tweetMessage to set
	 */
	public void setTweetMsg(String tweetMessage) {
		this.tweetMsg = tweetMessage;
	}

}
