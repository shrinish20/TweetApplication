package com.tweetapp.dao;

import java.sql.SQLException;
import java.util.List;
import com.tweetapp.model.UserPOJO;

public interface UserDAO {

	boolean insertUserDetails(UserPOJO userObj) throws SQLException;

	String validateUserCredentials(String emailId, String password) throws SQLException;

	boolean validID(String emailId) throws SQLException;

	boolean updatePassword(String emailId, String reenter) throws SQLException;

	List<UserPOJO> fetchAllUsers() throws SQLException;

}
