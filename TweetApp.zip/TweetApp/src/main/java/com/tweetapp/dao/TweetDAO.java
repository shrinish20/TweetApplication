package com.tweetapp.dao;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.model.TweetPOJO;

public interface TweetDAO {

	String postTweet(TweetPOJO tweetObj) throws SQLException;

	List<TweetPOJO> fetchTweets(String emailId) throws SQLException;

	List<TweetPOJO> fetchAllTweets() throws SQLException;

}
