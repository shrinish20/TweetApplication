package com.tweetapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tweetapp.dao.TweetDAO;
import com.tweetapp.dao.UserDAO;
import com.tweetapp.model.TweetPOJO;
import com.tweetapp.model.UserPOJO;
import com.tweetapp.service.TweetServiceImpl;
import com.tweetapp.service.UserServiceImpl;
import com.tweetapp.util.Constants;

public class App {	

	public static void main(String[] args) throws NumberFormatException {
		UserDAO userDao = new UserServiceImpl();
		Date date = new Date();
		Pattern emailPattern = Pattern.compile(Constants.EMAIL_PATTERN, Pattern.CASE_INSENSITIVE);
		System.out.println("******** Tweet App ********");
		System.out.println("Entering Tweet App ......");
		try {
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
			String fName = "", lName = "", gender = "", dOb = "", emailId = "", password = "";
			while (true) {
				int menu = menuForNonUser();
				switch (menu) {
				case 1:

					UserPOJO userObj = new UserPOJO();
					System.out.println("Enter the Registration Details ....");
					System.out.println("Enter First Name: ");
					fName = bufferedReader.readLine();
					System.out.println("Enter Last Name: ");
					lName = bufferedReader.readLine();
					System.out.println("Enter Gender: ");
					gender = bufferedReader.readLine();
					while (!("Male".equalsIgnoreCase(gender) || "Female".equalsIgnoreCase(gender)
							|| "Transgender".equalsIgnoreCase(gender))) {
						System.err.println("Please enter valid gender...");
						gender = bufferedReader.readLine();
					}
					System.out.println("Enter Date Of Birth (dd-MM-yyyy): ");
					dOb = bufferedReader.readLine();
					try {
						date = new SimpleDateFormat("YYYY-MM-DD").parse(dOb);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					System.out.println("Enter EmailId: ");
					while (true) {
						emailId = bufferedReader.readLine();
						Matcher matcher = emailPattern.matcher(emailId);
						if (!matcher.find()) {
							System.err.println("Enter valid email address ...");
						} else {
							break;
						}
					}
					System.out.println("Enter Password: ");
					password = bufferedReader.readLine();
					userObj.setFirstName(fName);
					userObj.setLastName(lName);
					userObj.setGender(gender);
					userObj.setDob(date);
					userObj.setEmailId(emailId);
					userObj.setUserPassword(password);
					if (userDao.insertUserDetails(userObj)) {
						System.out.println("User has been added successfully ...");
					} else {
						System.err.println("User already exists...");
					}
					break;

				case 2:

					System.out.println("Enter Username: ");
					emailId = bufferedReader.readLine();
					System.out.println("Enter Password: ");
					password = bufferedReader.readLine();
					String valid = userDao.validateUserCredentials(emailId, password);
					if (valid.contains("Success")) {
						System.out.println("User logged in successfully..");
						menuForUser(emailId, valid.substring(8));
					} else {
						System.err.println(valid);
					}
					break;

				case 3:

					System.out.println("Enter Username: ");
					emailId = bufferedReader.readLine();
					if (!userDao.validID(emailId)) {
						System.err.println("User does not exist...");
					} else {
						resetPassword(emailId);
					}
					break;

				default:

					System.err.println("Invalid option...");
					System.exit(0);
					break;

				}
				System.out.println();
			}
		} catch (SQLException sqlException) {
			System.out.println(sqlException.getMessage());
		} catch (IOException ioException) {
			System.out.println(ioException.getMessage());
		}
	}


	public static void resetPassword(String emailId) throws SQLException {
		UserDAO userDao = new UserServiceImpl();
		String confirm = "", pwd = "";
		try {
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Re-set Password: ");
			pwd = bufferedReader.readLine();
			
			System.out.println("Confirm Password: ");
			confirm = bufferedReader.readLine();
			while (true) {
				
				if (!confirm.equals(pwd)) {
					System.err.println("Password Mismatch... Re-Enter Password Again....");
				} else {
					String message = (userDao.updatePassword(emailId, confirm)) ? "\nPassword Changed Successfully..."
							: "\nPassword Change Unsuccessful.. Please try again...";
					System.out.println(message);
					break;
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void menuForUser(String emailId, String name)
			throws NumberFormatException, IOException, SQLException {
		
		TweetDAO tweetDao = new TweetServiceImpl();
		UserDAO userDao = new UserServiceImpl();
		List<TweetPOJO> tweetList = new ArrayList<TweetPOJO>();
		List<UserPOJO> userList = new ArrayList<UserPOJO>();
		TweetPOJO tweetObj = new TweetPOJO();
		
		int option;
		boolean logout = false;
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			System.out.println("Select any options below......\n");
			System.out.println("1. Post a tweet");
			System.out.println("2. View my tweets");
			System.out.println("3. View all tweets");
			System.out.println("4. View all Users");
			System.out.println("5. Reset Password");
			System.out.println("6. Logout\n");
			System.out.println("Enter your choice: ");
			option = Integer.parseInt(input.readLine());			
			String tweetMsg = "", result = "";
			switch (option) {
			case 1:

				System.out.println("Enter the tweet message...");
				tweetMsg = input.readLine();
				tweetObj.setEmailId(emailId);
				tweetObj.setTweetMsg(tweetMsg);
				result = tweetDao.postTweet(tweetObj);
				System.out.println(result);
				break;

			case 2:

				System.out.println("Your tweets...\n");
				tweetList = tweetDao.fetchTweets(emailId);
				if (tweetList != null) {
					tweetList.forEach(tweets -> System.out
							.println(tweets.getTweetMsg()));
				} else {
					System.out.println("No Tweets Found");
				}
				break;

			case 3:

				System.out.println("All tweets...\n");
				tweetList = tweetDao.fetchAllTweets();
				if (tweetList != null) {
					tweetList.forEach(tweets -> 
					System.out.println(tweets.getTweetMsg() + "\nPosted By - "
							+ tweets.getEmailId()));
				} else {
					System.out.println("No Tweets Found");
				}
				break;

			case 4:

				System.out.println("All users...\n");
				userList = userDao.fetchAllUsers();
				if (userList != null) {
					userList.forEach(users -> System.out.println(users.getEmailId()));
				} else {
					System.out.println("No Results Found...");
				}
				break;

			case 5:

				System.out.println("Password Resetting...");
				resetPassword(emailId);
				break;

			case 6:
				logout = true;
				System.out.println("Logged out Successfully");
				break;

			default:
				System.err.println("Invalid option...");
				input.close();
				System.exit(0);
				break;
			}
			if (logout) {
				break;
			}
			System.out.println();
		}
	}

	public static int menuForNonUser() throws NumberFormatException, IOException {
		int option;
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("To Continue Further, Select any options below......\n");
		System.out.println("1. Register");
		System.out.println("2. Login");
		System.out.println("3. Forgot Password");		
		System.out.println("Enter you choice: ");
		option = Integer.parseInt(input.readLine());
		return option;
	}
}
