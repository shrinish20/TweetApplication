package com.tweetapp.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.MysqlDataSource;
import com.tweetapp.dao.TweetDAO;
import com.tweetapp.model.TweetPOJO;
import com.tweetapp.util.DatabaseConnectionUtils;
import com.tweetapp.util.Constants;

public class TweetServiceImpl implements TweetDAO {	

	private Connection connection;
	private PreparedStatement prepardStatment;
	private ResultSet result;
	MysqlDataSource datasource = DatabaseConnectionUtils.getDatabaseConnection();

	public String postTweet(TweetPOJO tweetObj) throws SQLException {		
		int res = 0;
		String response = "";

		try {
			connection = datasource.getConnection();
			prepardStatment = connection.prepareStatement(Constants.SAVE_TWEET);
			prepardStatment.setString(1, tweetObj.getEmailId());
			prepardStatment.setString(2, tweetObj.getTweetMsg());
			res = prepardStatment.executeUpdate();
			response = (res > 0) ? "Tweet Posted Successfully..." : "Tweet Unsuccessful...";
		} finally {
			closeAllConnection();
		}		
		return response;
	}

	public List<TweetPOJO> fetchTweets(String emailId) throws SQLException {		
		List<TweetPOJO> response = new ArrayList<TweetPOJO>();
		try {
			connection = datasource.getConnection();
			prepardStatment = connection.prepareStatement(Constants.FETCH_TWEETS);
			prepardStatment.setString(1, emailId);
			result = prepardStatment.executeQuery();
			while (result.next()) {
				TweetPOJO tweetObj = new TweetPOJO();
				tweetObj.setTweetMsg(result.getString("tweet"));				
				response.add(tweetObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());
		} finally {
			closeAllConnection();
		}		
		return response;
	}

	public List<TweetPOJO> fetchAllTweets() throws SQLException {		
		List<TweetPOJO> response = new ArrayList<TweetPOJO>();
		try {
			connection = datasource.getConnection();
			prepardStatment = connection.prepareStatement(Constants.VIEW_ALLUSER_TWEETS);
			result = prepardStatment.executeQuery();
			while (result.next()) {
				TweetPOJO tweetObj = new TweetPOJO();
				tweetObj.setEmailId(result.getString("email"));
				tweetObj.setTweetMsg(result.getString("tweet"));				
				response.add(tweetObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());
		} finally {
			closeAllConnection();
		}		
		return response;
	}

	public void closeAllConnection() throws SQLException {
		if (connection != null) {
			connection.close();
		}
		if (result != null) {
			result.close();
		}
		if (prepardStatment != null) {
			prepardStatment.close();
		}
	}
}
