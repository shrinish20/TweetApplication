package com.tweetapp.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.MysqlDataSource;
import com.tweetapp.dao.UserDAO;
import com.tweetapp.model.UserPOJO;
import com.tweetapp.util.DatabaseConnectionUtils;
import com.tweetapp.util.Constants;

public class UserServiceImpl implements UserDAO {	

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet result;

	MysqlDataSource datasource = DatabaseConnectionUtils.getDatabaseConnection();

	public boolean insertUserDetails(UserPOJO userObj) throws SQLException {		
		if (!validID(userObj.getEmailId())) {
			java.sql.Date sqlDate = null;
			if (userObj.getDob() != null) {
				sqlDate = new Date(userObj.getDob().getTime());
			}
			int res = 0;
			try {
				connection = datasource.getConnection();
				preparedStatement = connection.prepareStatement(Constants.SAVE_USERDETAILS);
				preparedStatement.setString(1, userObj.getFirstName());
				preparedStatement.setString(2, userObj.getLastName());
				preparedStatement.setString(3, userObj.getGender());
				preparedStatement.setDate(4, sqlDate);
				preparedStatement.setString(5, userObj.getEmailId());
				preparedStatement.setString(6, userObj.getUserPassword());
				res = preparedStatement.executeUpdate();
				if (res > 0) {
					return true;
				}
			} finally {
				closeAllConnection();
			}
		}
		return false;
	}

	public boolean validID(String emailId) throws SQLException {

		connection = datasource.getConnection();
		preparedStatement = connection.prepareStatement(Constants.CHECK_EMAIL);
		preparedStatement.setString(1, emailId);
		result = preparedStatement.executeQuery();
		if (result.next())
			return result.getInt("flag") == 1 ? true : false;		
		return false;
	}

	public String validateUserCredentials(String emailId, String password) throws SQLException {		
		String userPassword = "", firstName = "";
		String response = "";
		try {
			connection = datasource.getConnection();
			if (!validID(emailId)) {
				response = "User does not exist..";
				return response;
			} else {
				preparedStatement = connection.prepareStatement(Constants.CHECK_CREDENTIALS);
				preparedStatement.setString(1, emailId);
				result = preparedStatement.executeQuery();
				if (result.next()) {
					userPassword = result.getString("userPassword");
					firstName = result.getString("firstName");
				}
				if (!password.equalsIgnoreCase(userPassword)) {
					response = "Invalid Credentials... ";
					return response;
				} else {
					response = "Success " + firstName;
				}
			}
		} finally {
			closeAllConnection();
		}		
		return response;
	}

	public boolean updatePassword(String emailAddress, String password) throws SQLException {		
		int update = 0;
		try {
			connection = datasource.getConnection();
			preparedStatement = connection.prepareStatement(Constants.RESET_PASSWORD);
			preparedStatement.setString(1, emailAddress);
			preparedStatement.setString(2, password);
			update = preparedStatement.executeUpdate();
			if (update > 0) {
				return true;
			}

		} finally {
			closeAllConnection();
		}		
		return false;
	}

	public List<UserPOJO> fetchAllUsers() throws SQLException {		
		List<UserPOJO> response = new ArrayList<UserPOJO>();
		try {
			connection = datasource.getConnection();
			preparedStatement = connection.prepareStatement(Constants.VIEW_ALL_USERS);
			result = preparedStatement.executeQuery();
			while (result.next()) {
				UserPOJO userObj = new UserPOJO();
				userObj.setEmailId(result.getString("emailAddress"));
				response.add(userObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());			
		} finally {
			closeAllConnection();
		}		
		return response;
	}

	public void closeAllConnection() throws SQLException {
		if (connection != null) {
			connection.close();
		}
		if (result != null) {
			result.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
	}

}
