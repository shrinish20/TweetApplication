package com.tweetapp.util;

import java.io.IOException;
import java.util.Properties;
import com.mysql.cj.jdbc.MysqlDataSource;

public class DatabaseConnectionUtils {	

	public static MysqlDataSource getDatabaseConnection() {
		MysqlDataSource datasource = new MysqlDataSource();
		Properties properties = new Properties();
		try {			
			properties.load(new java.io.FileInputStream("src/main/resources/datasource.properties"));
			datasource.setURL(properties.getProperty("mysql.url"));
			datasource.setUser(properties.getProperty("mysql.username"));
			datasource.setPassword(properties.getProperty("mysql.password"));
		} catch (IOException e) {
			System.out.println("Unable to establish a Database Connection..." + e.getMessage());
		}
		return datasource;
	}
}
