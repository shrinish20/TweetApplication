package com.tweetapp.util;

public class Constants {

	public static final String EMAIL_PATTERN = "^[A-Z0-9+_.-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";	

	public static final String SAVE_USERDETAILS = "INSERT INTO `tweetapplication`.`userdata` (`firstName`, `lastName`, `gender`, `dateOfBirth`, `emailAddress`, `userPassword`) VALUES(?, ?, ?, ?, ?, ?)";
	
	public static final String SAVE_TWEET = "INSERT INTO `tweetapplication`.`tweetdata` (`emailAddress`, `tweet`) VALUES (?, ?)";
	
	public static final String FETCH_TWEETS = "SELECT tweet FROM `tweetapplication`.`tweetdata` where emailAddress = ?";

	public static final String VIEW_ALLUSER_TWEETS = "SELECT emailAddress, tweet FROM `tweetapplication`.`tweetdata`";

	public static final String VIEW_ALL_USERS = "SELECT emailAddress FROM `tweetapplication`.`userdata`";

	public static final String CHECK_EMAIL = "SELECT EXISTS(SELECT * FROM `tweetapplication`.`userdata` WHERE upper(emailAddress) = upper(?)) AS flag";

	public static final String CHECK_CREDENTIALS = "SELECT firstName, userPassword FROM `tweetapplication`.`userdata` where upper(emailAddress) = upper(?)";

	public static final String RESET_PASSWORD = "UPDATE `tweetapplication`.`userdata` SET userPassword = ? where upper(emailAddress) = upper(?)";	

}
